"""Privileged engineering controller; NEVER report these as agent results."""
import math
import numpy as np

from simulator.benchmark.pilot import Author


class TabletopAuthor(Author):
    def __init__(self, env, folder, seed=0):
        super().__init__(env, folder, record=False, seed=seed)
        self.yaws = [0., 0.]

    def act(self, arm, token):
        super().act(arm, token)
        if token.startswith("YAW_"):
            self.yaws[arm] += math.radians(10)*(1 if token == "YAW_POS" else -1)

    def align(self, arm, angle):
        for _ in range(20):
            error = (angle-self.yaws[arm]+math.pi) % (2*math.pi)-math.pi
            if abs(error) < .1:
                return
            self.act(arm, "YAW_POS" if error > 0 else "YAW_NEG")
        raise RuntimeError("Wrist orientation did not converge")

    def park(self, arm):
        super().park(arm); self.align(arm, 0.)

    def pick(self, name, arm, grasp_offset=None):
        s = self.env.by_spec[name]
        if s["kind"] == "cup":
            self.align(arm, math.pi/2)
            return super().pick(name, arm, .015)
        return super().pick(name, arm, .009 if s["size"][2] <= .03 else min(.025, s["size"][2]*.45))

    def put(self, name, arm, target):
        target = np.asarray(target)
        self.move(arm, [*self.eef(arm)[:2], max(1.14, target[2]+.18)], axes=(2,))
        offset = self.eef(arm)-self.state(name)["pos"]
        self.move(arm, target+offset, axes=(0, 1)); self.wait(2)
        for _ in range(35):
            state = self.state(name)
            extent = (np.abs(state["mat"]) @ self.env.by_spec[name]["size"])[2]
            if state["pos"][2]-extent <= target[2]-self.env.by_spec[name]["size"][2]+.018:
                break
            self.act(arm, "DOWN")
        for _ in range(3): self.act(arm, "RELEASE")
        self.move(arm, [*self.eef(arm)[:2], 1.14], axes=(2,)); self.wait(3)

    def transport(self, name, arm, xy, bottom=.8, yaw=None):
        self.pick(name, arm)
        if yaw is not None:
            a = self.state(name)["mat"]
            current = math.atan2(a[1, 0], a[0, 0])
            self.align(arm, self.yaws[arm]+yaw-current)
        self.put(name, arm, [*xy, bottom+self.env.by_spec[name]["size"][2]])
        self.park(arm)

    def solve(self):
        self.park(0); self.park(1)
        for p in self.env.spec["author_plan"]:
            name = p["object"]
            src = self.state(name)["pos"]
            arm = 0 if src[1] < 0 else 1
            target_arm = 0 if p["xy"][1] < -.07 else 1 if p["xy"][1] > .07 else arm
            if arm != target_arm:
                self.transport(name, arm, [-.10, 0.])
                arm = target_arm
            self.transport(name, arm, p["xy"], p["bottom"], p.get("yaw"))
        self.wait(6)
