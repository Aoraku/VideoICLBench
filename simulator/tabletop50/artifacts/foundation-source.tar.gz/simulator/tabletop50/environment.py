"""Real MuJoCo contacts and dual-Panda actions, with a first-person-like camera.

This is a simulated camera, not evidence that a human recording has been made.
"""
import math
import xml.etree.ElementTree as ET

import numpy as np
from robosuite.models.arenas import TableArena
from robosuite.models.tasks import ManipulationTask
from robosuite.utils.transform_utils import mat2quat

from simulator.benchmark.environment import DesktopDual, make_object


def marker(body, xy, index, radius=.045, z=.803):
    count = (16, 3, 4)[index]
    points = [[xy[0]+radius*math.cos(2*math.pi*i/count),
               xy[1]+radius*math.sin(2*math.pi*i/count), z] for i in range(count)]
    for i, a in enumerate(points):
        b = points[(i+1) % count]
        ET.SubElement(body, "geom", type="capsule", size=".002",
                      fromto=" ".join(map(str, a+b)), rgba=".95 .85 .15 1",
                      contype="0", conaffinity="0", group="1")


class TabletopDual(DesktopDual):
    def _load_model(self):
        # Preserve existing motor/controller physics; build a new tabletop scene.
        super(DesktopDual, self)._load_model()
        for robot, offset in zip(self.robots, (-.25, .25)):
            base = np.array(robot.robot_model.base_xpos_offset["table"](.8))+[0, offset, 0]
            robot.robot_model.set_base_xpos(base)
        arena = TableArena(table_full_size=(.8, .8, .05), table_offset=self.table_offset,
                           table_friction=(1, .005, .0001))
        arena.set_origin([0, 0, 0])
        for zone in self.spec["zones"]:
            ET.SubElement(arena.worldbody, "geom", name="zone_"+zone["id"], type="box",
                          size=" ".join(map(str, zone["half_size"]+[.001])),
                          pos=" ".join(map(str, zone["xy"]+[.801])),
                          rgba=".30 .37 .44 1", contype="0", conaffinity="0", group="1")
            marker(arena.worldbody, zone["xy"], zone.get("marker", 0))
        position = np.array([-.55, 0., 1.48])
        target = np.array([.03, 0., .82])
        back = (position-target)/np.linalg.norm(position-target)
        right = np.cross([0, 0, 1], back); right /= np.linalg.norm(right)
        up = np.cross(back, right)
        q = mat2quat(np.column_stack([right, up, back]))[[3, 0, 1, 2]]
        ET.SubElement(arena.worldbody, "camera", name="fpv", fovy="65",
                      pos=" ".join(map(str, position)), quat=" ".join(map(str, q)))
        self.items = {}
        for s in self.spec["objects"]:
            item = make_object(s)
            if s["kind"] == "arrow_bar":
                b = item.get_obj()
                x, y, z = s["size"]
                for a, end in (([-x*.6, 0, z+.002], [x*.6, 0, z+.002]),
                               ([x*.6, 0, z+.002], [x*.2, y*.65, z+.002]),
                               ([x*.6, 0, z+.002], [x*.2, -y*.65, z+.002])):
                    ET.SubElement(b, "geom", type="capsule", size=".002",
                                  fromto=" ".join(map(str, a+end)), rgba="1 1 1 1",
                                  contype="0", conaffinity="0", group="1")
            if s["id"].startswith("bin"):
                # Marker at rim height, just beyond the interior contents.
                marker(item.get_obj(), [0, -s["size"][1]+.012], int(s["id"][-1]), radius=.008, z=s["size"][2]+.002)
            self.items[s["id"]] = item
        self.model = ManipulationTask(mujoco_arena=arena,
            mujoco_robots=[r.robot_model for r in self.robots], mujoco_objects=list(self.items.values()))

    def images(self):
        import base64
        import io
        from PIL import Image
        out = {}
        for camera in ("fpv", "robot0_eye_in_hand", "robot1_eye_in_hand"):
            pixels = self.sim.render(width=640, height=480, camera_name=camera)[::-1]
            stream = io.BytesIO(); Image.fromarray(pixels).save(stream, format="JPEG", quality=85)
            out[camera] = base64.b64encode(stream.getvalue()).decode()
        return out

    def score(self):
        result = super().score()
        # The only benchmark metric is terminal success. Hold time is settling,
        # never an additional weighted score or a mandated human motion.
        result["metric"] = "success"
        return result
