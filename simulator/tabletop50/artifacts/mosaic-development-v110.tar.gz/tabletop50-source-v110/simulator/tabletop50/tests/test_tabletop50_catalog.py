import pytest
from simulator.tabletop50.catalog import IMPLEMENTED, task_spec, visible_world, world_sha256
from simulator.tabletop50.families import BY_ID, FAMILIES


def test_all_families_have_recording_cards_and_distinct_rules():
    assert list(BY_ID) == [f"F{i:02d}" for i in range(1, 51)]
    for f in FAMILIES:
        assert set(f["rules"]) == set("ABC")
        assert len(set(f["rules"].values())) == 3
        assert f["props"] and f["reset"] and f["camera_note"]
        assert f["human_recording_status"] == "not-recorded-not-user-validated"


@pytest.mark.parametrize("task", IMPLEMENTED)
@pytest.mark.parametrize("seed", [0, 1, 19, 101])
def test_rule_never_changes_visible_initial_world(task, seed):
    specs = [task_spec(task, rule, seed) for rule in "ABC"]
    assert visible_world(specs[0]) == visible_world(specs[1]) == visible_world(specs[2])
    assert len({world_sha256(s) for s in specs}) == 1
    assert len({str(s["goals"]) for s in specs}) == 3
    names = {o["id"] for o in specs[0]["objects"]}
    for s in specs:
        assert all(p["object"] in names for p in s["author_plan"])


@pytest.mark.parametrize("task", ["F42"])
def test_missing_recipe_is_not_silently_replaced_with_generic_pick_place(task, monkeypatch):
    # All 50 now have recipes. Simulate a missing future implementation to
    # preserve the explicit refusal policy rather than a generic fallback.
    monkeypatch.setitem(BY_ID[task], "runtime_recipe", None)
    with pytest.raises(NotImplementedError): task_spec(task)


@pytest.mark.parametrize("task", IMPLEMENTED)
def test_demo_and_inference_can_use_different_worlds(task):
    assert world_sha256(task_spec(task, "A", 0)) != world_sha256(task_spec(task, "A", 101))


def test_layout_randomisation_does_not_translate_container_local_goals():
    specs = [task_spec("F35", "A", seed) for seed in [0, 19, 101]]
    local = [[g["xy"] for g in s["goals"] if g["type"] == "local_position"] for s in specs]
    assert local == [[[0., -.075], [0., 0.], [0., .075]]]*3


def test_prop_colours_do_not_share_mutable_catalogue_state():
    first = task_spec("F02")
    expected = visible_world(task_spec("F02"))
    first["objects"][0]["rgba"][0] = 0.
    task_spec("F40")  # Its transparent cup must not turn all white props transparent.
    assert visible_world(task_spec("F02")) == expected
    assert all(o["rgba"][3] == 1. for o in task_spec("F40")["objects"] if o["id"].startswith("bin"))


def test_mosaic_rules_are_rigid_transforms_of_a_square_reference():
    import numpy as np
    transforms = {"A": np.eye(2), "B": np.array([[0., 1.], [-1., 0.]]),
                  "C": np.array([[1., 0.], [0., -1.]])}
    for seed in [0, 19, 37]:
        for variant, transform in transforms.items():
            spec = task_spec("F10", variant, seed)
            refs = [o for o in spec["objects"] if o["id"].startswith("ref")]
            pieces = {o["id"]: o for o in spec["objects"] if o["id"].startswith("piece")}
            ref_center = np.mean([o["xy"] for o in refs], axis=0)
            targets = [g for g in spec["goals"] if g["object"].startswith("piece")]
            target_center = np.mean([g["xy"] for g in targets], axis=0)
            assert len({round(o["xy"][0], 6) for o in refs}) == 2
            assert len({round(o["xy"][1], 6) for o in refs}) == 2
            for goal in targets:
                reference = next(o for o in refs if o["rgba"] == pieces[goal["object"]]["rgba"])
                expected = target_center+transform@(np.array(reference["xy"])-ref_center)
                assert np.allclose(goal["xy"], expected)
            assert len(spec["fixtures"]) == 10
